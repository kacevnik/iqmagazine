<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Спасибо!</title>
<style>
body {
    color: #313E47;
    font-family: Arial;
    font-size: 15px;
    line-height: 1;
    text-align: center;
    background: url(body.jpg) repeat;
    padding-top: 20px;
}
h2 {
    color: #313E47;
    font-size: 36px;
    font-weight: 700;
    line-height: 44px;
    text-align: center;
    text-transform: uppercase;
}
</style>
</head>
<body>
    <img src="index.png">
    <h2>Поздравляем! Ваш заказ принят!</h2>
    <p class='success'>В ближайшее время с вами свяжется оператор для подтверждения заказа. Пожалуйста, включите ваш контактный телефон.</p>
    <h1 style='color:#FF0000; text-align: center;'>Спасибо что выбрали нас!</h1>
    <?php include("admin/params/scripts.txt"); ?>
</body>
</html>